package project;

import javax.naming.ldap.Control;

public class Main {

    public static void main(String[] args) {
	// write your code here
        Controller controller = new Controller();

        controller.main();
    }
}
