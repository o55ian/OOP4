package project.Views;

public class ViewRemoveItem {
}
